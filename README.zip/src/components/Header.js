import React from 'react';
export default function Header() {
  return (
    <header className="header">
      <div className="header__logo" />
    </header>
  )
}